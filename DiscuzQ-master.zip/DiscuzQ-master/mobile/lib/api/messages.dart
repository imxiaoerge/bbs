import 'package:flutter/widgets.dart';

class MessageAPI {
  const MessageAPI({@required this.context});

  final BuildContext context;
}
