Skeleton widget modified from: https://github.com/iampawan/PKSkeleton

Thanks for Iampawan's Greate job!!!