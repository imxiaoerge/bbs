import 'package:flutter/material.dart';

class DiscuzEditorAttachementUploader extends StatefulWidget {
  final Function onUploaded;
  const DiscuzEditorAttachementUploader({this.onUploaded});

  @override
  _DiscuzEditorAttachementUploaderState createState() =>
      _DiscuzEditorAttachementUploaderState();
}

class _DiscuzEditorAttachementUploaderState
    extends State<DiscuzEditorAttachementUploader> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
