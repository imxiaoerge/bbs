#import <Flutter/Flutter.h>

@interface ClipboardManagerPlugin : NSObject<FlutterPlugin>
@end
