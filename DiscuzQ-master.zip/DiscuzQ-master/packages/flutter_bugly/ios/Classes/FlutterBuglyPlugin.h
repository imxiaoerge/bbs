#import <Flutter/Flutter.h>

@interface FlutterBuglyPlugin : NSObject<FlutterPlugin>
@end
