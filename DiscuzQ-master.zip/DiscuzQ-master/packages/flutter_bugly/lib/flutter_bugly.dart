library flutter_bugly;

export 'src/flutter_bugly.dart';
export 'src/bean/upgrade_info.dart';