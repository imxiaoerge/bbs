# UDID（唯一设备标识符）

UDID`s full name is Unique Device Identifier。

Android reference:
https://blog.csdn.net/sunsteam/article/details/73189268
iOS reference:
https://github.com/herody/UQIDDemo



Sample usage to check current status:

```dart
import 'package:udid/udid.dart';

String udid = await Udid.udid;
```
## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).

For help on editing plugin code, view the [documentation](https://flutter.io/developing-packages/#edit-plugin-package).

