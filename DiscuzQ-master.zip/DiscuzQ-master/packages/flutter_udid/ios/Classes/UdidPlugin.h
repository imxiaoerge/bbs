#import <Flutter/Flutter.h>

@interface UdidPlugin : NSObject<FlutterPlugin>
@end
