## [0.1.2] - [April 1, 2020]

* Fixed issue "Type 'Color' is not a subtype of type 'bool'" 

## [0.1.1] - [December 3, 2019]

* Added description in pubspec.yaml

## [0.1.0] - [December 3, 2019]

* Initial release with basic StatusAlert.