# CONTRIBUTING

Please submit changes to master branch.

And make sure your code is willing to comply with MIT style.
