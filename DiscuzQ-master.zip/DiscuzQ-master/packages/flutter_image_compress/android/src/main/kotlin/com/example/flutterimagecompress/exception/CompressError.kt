package com.example.flutterimagecompress.exception

import java.lang.Exception

class CompressError(message: String) : Exception(message)