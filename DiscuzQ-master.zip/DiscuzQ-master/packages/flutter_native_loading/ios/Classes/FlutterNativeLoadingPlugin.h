#import <Flutter/Flutter.h>

@interface FlutterNativeLoadingPlugin : NSObject<FlutterPlugin>
@end
