# flutter_native_loading

The easy way to show loading indecator in flutter.

## Getting Started

### Show Loading
~~~dart
    FlutterNativeLoading.show();
~~~~
### Show Loading
~~~dart
    FlutterNativeLoading.hide();
~~~