## 0.0.1

* Adding default for IOS and Android

